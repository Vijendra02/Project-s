/**
 * WooCommerce Custom Professional Engine Orchestrator
 * VERSION: Definitive — Isolated State, Dynamic Price Core Alignment Fix
 *
 * ROOT CAUSE ANALYSIS FIXED:
 * ─────────────────────────────────────────────────────────────────────
 * WooCommerce alters variation wrapper selectors dynamically. By tracking 
 * single variation text nodes before falling back to global components, 
 * the base price dynamically mirrors actual values ($22 vs $20) cleanly.
 */

jQuery(document).ready(function ($) {
    const config = window.wcsConfigPayload;
    if (!config) return;

    // ═══════════════════════════════════════════════════════════════
    // ISOLATED STATE — one object per card, never shared or cross-polluted
    // clickTs = click timestamp (milliseconds). null = never clicked premium.
    // ═══════════════════════════════════════════════════════════════
    const cardState = {
        'color': {
            val:       '',     // current selected value
            isPremium: false,  // is current selection premium?
            clickTs:   null    // timestamp of last premium click (null = none)
        },
        'frame-color': {
            val:       '',
            isPremium: false,
            clickTs:   null
        }
    };

    // ─────────────────────────────────────────────
    // HELPER: Find the native WooCommerce <select>
    // ─────────────────────────────────────────────
    function getTargetSelect(slugKey) {
        let el = $('select#pa_' + slugKey);
        if (el.length) return el;

        el = $('.variations select[name="attribute_pa_' + slugKey + '"]');
        if (el.length) return el;

        el = $('select[data-attribute_name="attribute_pa_' + slugKey + '"]');
        if (el.length) return el;

        return $('select').filter(function () {
            let id   = $(this).attr('id')   || '';
            let name = $(this).attr('name') || '';
            return id.endsWith('pa_' + slugKey) || name.endsWith('pa_' + slugKey);
        }).first();
    }

    // ─────────────────────────────────────────────
    // BUILD: Render one card
    // ─────────────────────────────────────────────
    function buildCard(slugKey, indexNum, titleText, targetHost) {
        let nativeSelect = getTargetSelect(slugKey);
        if (!nativeSelect.length || $('#wcs-card-' + slugKey).length) return true;

        targetHost.append(`
            <div class="wcs-v8-card" id="wcs-card-${slugKey}">
                <div class="wcs-v8-header">
                    <div class="wcs-v8-header-left">
                        <div class="wcs-v8-number">${indexNum}</div>
                        <div class="wcs-v8-title">${titleText}</div>
                    </div>
                    <div class="wcs-v8-selected-txt" id="wcs-txt-${slugKey}">—</div>
                </div>
                <div class="wcs-v8-tier">
                    <div class="wcs-v8-meta">
                        <span class="wcs-v8-meta-lbl">Standard Colors</span>
                        <span class="wcs-v8-badge dynamic-badge-std">No up-charge</span>
                    </div>
                    <div class="wcs-v8-grid wcs-grid-standard"></div>
                </div>
                <div class="wcs-v8-tier">
                    <div class="wcs-v8-meta">
                        <span class="wcs-v8-meta-lbl">Premium Colors</span>
                        <span class="wcs-v8-badge premium-mode dynamic-badge-prem"
                              id="wcs-badge-${slugKey}">+$${parseFloat(config.premium_fee).toFixed(2)}</span>
                    </div>
                    <div class="wcs-v8-grid wcs-grid-premium"></div>
                </div>
            </div>
        `);

        const colorMap = {
            'antique-mahogany':    'background-color:#4b2d1f;',
            'birchwood':           'background-color:#dfcdb2;',
            'black':               'background-color:#111111;',
            'brazilian-walnut':    'background-color:#5c4033;',
            'cedar':               'background-color:#c2410c;',
            'cherrywood':          'background-color:#741b1b;',
            'coastal-gray':        'background-color:#6b7280;',
            'dark-gray':           'background-color:#374151;',
            'driftwood-gray':      'background-color:#9ca3af;',
            'ivory':               'background-color:#fefcbf;',
            'light-gray':          'background-color:#e5e7eb;',
            'milwaukee-brown':     'background-color:#78350f;',
            'natural-teak':        'background-color:#b45309;',
            'seashell':            'background-color:#fffaf0;',
            'tudor-brown':         'background-color:#451a03;',
            'walnut':              'background-color:#402312;',
            'weathered-wood':      'background-color:#857568;',
            'white':               'background-color:#ffffff;border:1px solid #cbd5e1!important;',
            'aruba-blue':          'background-color:#00b4d8;',
            'blue':                'background-color:#1e40af;',
            'bright-cedar':        'background-color:#d97706;',
            'bright-orange':       'background-color:#ea580c;',
            'bright-purple':       'background-color:#7c3aed;',
            'cardinal-red':        'background-color:#b91c1c;',
            'lemon-yellow':        'background-color:#eab308;',
            'patriot-blue':        'background-color:#1e3a8a;',
            'pink':                'background-color:#ec4899;',
            'powder-blue':         'background-color:#93c5fd;',
            'red':                 'background-color:#dc2626;',
            'tropical-lime-green': 'background-color:#22c55e;',
            'turf-green':          'background-color:#15803d;',
        };

        nativeSelect.find('option').each(function () {
            let val = $(this).val();
            if (!val) return;

            let slug         = val.toLowerCase().trim();
            let displayLabel = $(this).text().split('(')[0].trim();
            let styleStr     = '';

            let nativeSwatch = $(`.swatch[data-value="${val}"], .variable-item[data-value="${val}"]`).first();
            if (nativeSwatch.length) {
                let bgImg   = nativeSwatch.css('background-image');
                let bgColor = nativeSwatch.css('background-color');
                if (bgImg && bgImg !== 'none') styleStr = `background-image:${bgImg};`;
                else if (bgColor)               styleStr = `background-color:${bgColor};`;
            }
            if (!styleStr) styleStr = colorMap[slug] || '';

            let node = $(`
                <div class="wcs-v8-node" data-slug="${slug}" data-raw-val="${val}">
                    <div class="wcs-v8-circle" style="${styleStr}"></div>
                    <div class="wcs-v8-lbl">${displayLabel}</div>
                </div>
            `);

            if (config.premium_slugs.includes(slug)) {
                $('#wcs-card-' + slugKey + ' .wcs-grid-premium').append(node);
            } else {
                $('#wcs-card-' + slugKey + ' .wcs-grid-standard').append(node);
            }
        });

        // ═══════════════════════════════════════════════════════════════
        // CLICK HANDLER
        // ═══════════════════════════════════════════════════════════════
        $('#wcs-card-' + slugKey)
            .off('click', '.wcs-v8-node')
            .on('click', '.wcs-v8-node', function (e) {
                e.preventDefault();

                let rawVal     = $(this).attr('data-raw-val');
                let slug       = rawVal.toLowerCase().trim();
                let isPremium  = config.premium_slugs.includes(slug);
                let nativeSel  = getTargetSelect(slugKey);

                // Update THIS card's isolated state
                cardState[slugKey].val       = rawVal;
                cardState[slugKey].isPremium = isPremium;

                if (isPremium) {
                    cardState[slugKey].clickTs = Date.now();
                } else {
                    cardState[slugKey].clickTs = null;
                }

                // Update WooCommerce native select silently
                if (nativeSel.length) {
                    nativeSel.val(rawVal).trigger('change');
                }

                setTimeout(function () {
                    renderBadgesAndPricing();
                    $('form.variations_form').trigger('check_variations');
                }, 80);
            });

        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    // RENDER — pure read of cardState, zero writes to it
    // ═══════════════════════════════════════════════════════════════
    function renderBadgesAndPricing() {
        // Read live values from WooCommerce selects (source of truth for what's selected)
        let seatRaw  = getTargetSelect('color').val()       || '';
        let frameRaw = getTargetSelect('frame-color').val() || '';

        let seatSlug  = seatRaw.toLowerCase().trim();
        let frameSlug = frameRaw.toLowerCase().trim();

        let isSPremium = seatSlug  ? config.premium_slugs.includes(seatSlug)  : false;
        let isFPremium = frameSlug ? config.premium_slugs.includes(frameSlug) : false;

        // Sync values safely
        if (!seatRaw  && cardState['color']['val'])       cardState['color']['val'] = '';
        if (!frameRaw && cardState['frame-color']['val']) cardState['frame-color']['val'] = '';

        if (!isSPremium && cardState['color']['clickTs'] !== null) {
            cardState['color']['clickTs'] = null;
        }
        if (!isFPremium && cardState['frame-color']['clickTs'] !== null) {
            cardState['frame-color']['clickTs'] = null;
        }

        // ── Highlight selected nodes ──
        $('.wcs-v8-node').removeClass('is-selected');

        if (seatRaw) {
            let n = $('#wcs-card-color .wcs-v8-node[data-raw-val="' + seatRaw + '"]');
            n.addClass('is-selected');
            $('#wcs-txt-color').text(n.find('.wcs-v8-lbl').text() || '—');
        } else {
            $('#wcs-txt-color').text('—');
        }

        if (frameRaw) {
            let n = $('#wcs-card-frame-color .wcs-v8-node[data-raw-val="' + frameRaw + '"]');
            n.addClass('is-selected');
            $('#wcs-txt-frame-color').text(n.find('.wcs-v8-lbl').text() || '—');
        } else {
            $('#wcs-txt-frame-color').text('—');
        }

        // ── Badge styles ──
        const styleBlue     = 'background-color:#e1f5fe!important;color:#0288d1!important;border:none!important;font-size:11px!important;display:inline-block!important;visibility:visible!important;opacity:1!important;';
        const styleIncluded = 'background-color:#def7ec!important;color:#03543f!important;border:1px solid #bcf0da!important;font-size:11px!important;display:inline-block!important;visibility:visible!important;opacity:1!important;';

        let feeText      = '+$' + parseFloat(config.premium_fee).toFixed(2);
        let includedText = 'Included — already covered';

        let topBadge    = $('#wcs-badge-color');
        let bottomBadge = $('#wcs-badge-frame-color');

        topBadge.removeAttr('style');
        bottomBadge.removeAttr('style');

        let sTs = cardState['color']['clickTs'];
        let fTs = cardState['frame-color']['clickTs'];

        let bothPremiumAndBothClicked = isSPremium && isFPremium && sTs !== null && fTs !== null;

        if (bothPremiumAndBothClicked) {
            if (sTs <= fTs) {
                topBadge.text(feeText).attr('style', styleBlue);
                bottomBadge.text(includedText).attr('style', styleIncluded);
            } else {
                topBadge.text(includedText).attr('style', styleIncluded);
                bottomBadge.text(feeText).attr('style', styleBlue);
            }
        } else {
            topBadge.text(feeText).attr('style', styleBlue);
            bottomBadge.text(feeText).attr('style', styleBlue);
        }

        // ── Pricing label ──
        let labelText = 'Premium Color Charge:';
        if      (isSPremium && isFPremium) labelText = 'Premium Color (Seat & Frame — Covered):';
        else if (isSPremium)                labelText = 'Premium Color (Seat):';
        else if (isFPremium)                labelText = 'Premium Color (Frame):';
        $('#ui-premium-label-text').text(labelText);

        // ── Fee ──
        let extraFee = (isSPremium || isFPremium) ? parseFloat(config.premium_fee) : 0;
        $('#ui-premium-charge').text(extraFee > 0 ? '+$' + extraFee.toFixed(2) : '$0.00');

        // ── FIXED DYNAMIC BASE PRICE CALCULATOR PIPELINE ──
        let basePrice = 0;
        let form = $('form.variations_form');
        let variationData = form.data('product_variations');

        // HIGH PRIORITY SELECTOR: Check active continuous inner variation nodes first
        let nativePriceText = $(
            '.woocommerce-variation-price .price .woocommerce-Price-amount amount, ' +
            '.woocommerce-variation-price .price span.amount'
        ).last().text();

        // FALLBACK SELECTOR: Check summary container if single variation details haven't populated yet
        if (!nativePriceText) {
            nativePriceText = $(
                '.summary .price .woocommerce-Price-amount amount, ' +
                '.summary .price span.amount'
            ).last().text();
        }

        if (nativePriceText) {
            let parsed = parseFloat(nativePriceText.replace(/[^\d.]/g, ''));
            if (!isNaN(parsed) && parsed > 0) {
                basePrice = parsed;
            }
        }

        // Safe subtraction if dynamic price already loaded premium fees natively
        if ((isSPremium || isFPremium) && basePrice > parseFloat(config.premium_fee)) {
            basePrice = basePrice - parseFloat(config.premium_fee);
        }

        // Secondary state data parsing engine fallback
        if (!basePrice) {
            let d = $('#ui-product-total').text().replace(/[^\d.]/g, '');
            basePrice = d ? parseFloat(d) : 0;
        }

        if (!basePrice && variationData && variationData[0]) {
            basePrice = parseFloat(variationData[0].display_regular_price || variationData[0].display_price);
        }

        let total = basePrice + extraFee;
        if (basePrice > 0) {
            $('#ui-product-total').text('$' + basePrice.toFixed(2));
            $('#ui-grand-total').text('$' + total.toFixed(2));
        }

        // ── Enable Add to Cart ──
        if (seatRaw && frameRaw) {
            $('.single_add_to_cart_button')
                .removeClass('disabled wc-variation-selection-needed')
                .prop('disabled', false);
        }
    }

    // ─────────────────────────────────────────────
    // BOOT
    // ─────────────────────────────────────────────
    let loopCounter = 0;

    function executionEngine() {
        let targetForm = $('form.variations_form');

        if (!targetForm.length && loopCounter < 50) {
            loopCounter++;
            setTimeout(executionEngine, 200);
            return;
        }

        if (!$('.wcs-v8-injection-host').length) {
            targetForm.prepend('<div class="wcs-v8-injection-host"></div>');
        }

        let host = $('.wcs-v8-injection-host');
        buildCard('color',       '1', 'Seat Color (Top & Seat)', host);
        buildCard('frame-color', '2', 'Frame Color',             host);

        renderBadgesAndPricing();
        
        // Polling hook ensures UI block alignment stays reactive 
        setInterval(function() {
            renderBadgesAndPricing();
        }, 150);
    }

    // ─────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────
    $(document).on(
        'woocommerce_variation_has_changed found_variation check_variations update_variations show_variation',
        function () { setTimeout(renderBadgesAndPricing, 80); }
    );

    $(document).on(
        'change',
        'select[name="attribute_pa_color"], select[name="attribute_pa_frame-color"]',
        function () { setTimeout(renderBadgesAndPricing, 80); }
    );

    executionEngine();
});