<?php
/**
 * Plugin Name: WooCommerce Dynamic Conditional Swatch Logic - Professional Architecture
 * Description: High-end professional architecture with separate assets, configuration matrix, and decoupled core systems. Handles all 31 color variations dynamically with strict activation and deactivation hooks.
 * Version: 1
 * Author: Vijendra Developer
 * Text Domain: wcs-conditional-swatches
 * Shortcode : [color_dynamic_calculator]
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define Core Plugin Constants
define( 'WCS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WCS_VERSION', '12.0.0' );

// Include Structural Dependency Classes
require_once WCS_PLUGIN_DIR . 'includes/class-wcs-config.php';
require_once WCS_PLUGIN_DIR . 'includes/class-wcs-frontend.php';
require_once WCS_PLUGIN_DIR . 'includes/class-wcs-cart.php';

/**
 * PLUGIN ACTIVATION HOOK
 * Checks dependencies before letting the plugin turn on.
 */
register_activation_hook( __FILE__, 'wcs_plugin_activation_safeguard' );
function wcs_plugin_activation_safeguard() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 
            __( '<strong>Activation Error:</strong> This plugin requires <strong>WooCommerce</strong> to be installed and active.', 'wcs-conditional-swatches' ), 
            'Plugin Activation Error', 
            array( 'back_link' => true ) 
        );
    }
    
    // Pro Developer Tip: Clear rewrite rules if needed on activation
    flush_rewrite_rules();
}

/**
 * PLUGIN DEACTIVATION HOOK
 * Cleans up the system state when disabled.
 */
register_deactivation_hook( __FILE__, 'wcs_plugin_deactivation_cleanup' );
function wcs_plugin_deactivation_cleanup() {
    // Clear dynamic operational caches and rewrite paths cleanly
    flush_rewrite_rules();
    
    // (Optional) Remove temporary options or transients if stored
    delete_transient( 'wcs_color_rules_cache' );
}

/**
 * CORE ENGINE INITIALIZATION
 * Initialize components safely after all active plugins load completely
 */
add_action( 'plugins_loaded', 'wcs_initialize_professional_architecture' );
function wcs_initialize_professional_architecture() {
    if ( class_exists( 'WooCommerce' ) ) {
        WCS_Frontend::init();
        WCS_Cart::init();
    } else {
        add_action( 'admin_notices', 'wcs_woocommerce_missing_admin_notice' );
    }
}

function wcs_woocommerce_missing_admin_notice() {
    ?>
    <div class="notice notice-error is-dismissible">
        <p><?php _e( '<strong>WooCommerce Dynamic Conditional Swatch Logic</strong> is currently inactive because the core WooCommerce system cannot be verified.', 'wcs-conditional-swatches' ); ?></p>
    </div>
    <?php
}