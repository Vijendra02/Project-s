<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCS_Frontend {
    
    public static function init() {
        add_shortcode( 'color_dynamic_calculator', array( __CLASS__, 'render_breakdown_card' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_professional_assets' ) );
    }

    /**
     * Enqueue asset layers securely with specific cache busting versions
     */
    public static function enqueue_professional_assets() {
        if ( is_product() ) {
            // Style Injection
            wp_enqueue_style( 'wcs-core-styles', WCS_PLUGIN_URL . 'assets/css/wcs-styles.css', array(), WCS_VERSION );

            // Script Engine Injection
            wp_enqueue_script( 'wcs-core-engine', WCS_PLUGIN_URL . 'assets/js/wcs-engine.js', array( 'jquery' ), WCS_VERSION, true );

            // Pass backend configuration payload to local JS context
            wp_localize_script( 'wcs-core-engine', 'wcsConfigPayload', WCS_Config::get_rules() );
        }
    }

    /**
     * Render UI Breakdown Structure
     */
    public static function render_breakdown_card() {
        if ( ! is_product() ) return '';
        
        global $product;
        $dynamic_base_price = 0;

        if ( $product ) {
            if ( $product->is_type( 'variable' ) ) {
                $dynamic_base_price = $product->get_variation_price( 'min', true );
            } else {
                $dynamic_base_price = $product->get_price();
            }
        }

        if ( ! $dynamic_base_price || $dynamic_base_price == 0 ) {
            $dynamic_base_price = 433.75;
        }
        
        ob_start();
        ?>
        <div class="wcs-main-price-breakdown-card">
            <h4>Price Breakdown</h4>
            
            <div class="wcs-price-row">
                <span>Base Price</span>
                <span id="ui-product-total">$<?php echo esc_html(number_format(floatval($dynamic_base_price), 2)); ?></span>
            </div>
            
            <div class="wcs-price-row premium-highlight">
                <span id="ui-premium-label-text">Premium Color Charge</span>
                <span id="ui-premium-charge">$0.00</span>
            </div>
            
            <hr class="wcs-divider" />
            
            <div class="wcs-price-row grand-total-row">
                <span class="wcs-total-label">Total</span>
                <span id="ui-grand-total">$<?php echo esc_html(number_format(floatval($dynamic_base_price), 2)); ?></span>
            </div>
        </div>
        
        <!-- <div class="wcs-bottom-trust-grid">
            <div class="wcs-trust-card">🛡️<br/><span>20-Year Warranty</span></div>
            <div class="wcs-trust-card">🌧️<br/><span>Weather Resistant</span></div>
            <div class="wcs-trust-card">✅<br/><span>Maintenance Free</span></div>
            <div class="wcs-trust-card">☀️<br/><span>Fade Resistant</span></div>
        </div> -->
        <?php
        return ob_get_clean();
    }
}