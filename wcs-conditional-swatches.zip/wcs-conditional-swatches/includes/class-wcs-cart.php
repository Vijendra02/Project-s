<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCS_Cart {

    public static function init() {
        add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply_conditional_pricing' ), 99, 1 );
    }

    /**
     * Compute and enforce proper validation rule logic over server-side cart
     */
    public static function apply_conditional_pricing( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
        
        $rules = WCS_Config::get_rules();

        foreach ( $cart->get_cart() as $key => $item ) {
            $product = $item['data'];
            if ( $product->is_type( 'variation' ) ) {
                $base_price = floatval( $product->get_regular_price() );
                if ( ! $base_price || $base_price == 0 ) {
                    $base_price = 433.75;
                }

                $attrs = $product->get_variation_attributes();
                $seat  = isset( $attrs['attribute_pa_color'] ) ? $attrs['attribute_pa_color'] : '';
                $frame = isset( $attrs['attribute_pa_frame-color'] ) ? $attrs['attribute_pa_frame-color'] : '';

                $is_s_premium = in_array( strtolower( $seat ), $rules['premium_slugs'] );
                $is_f_premium = in_array( strtolower( $frame ), $rules['premium_slugs'] );

                if ( $is_s_premium || $is_f_premium ) {
                    $product->set_price( $base_price + $rules['premium_fee'] );
                } else {
                    $product->set_price( $base_price );
                }
            }
        }
    }
}