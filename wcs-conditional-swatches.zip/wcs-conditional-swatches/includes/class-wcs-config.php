<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class WCS_Config {
    /**
     * Return centralized operational rules matrix
     */
    public static function get_rules() {
        return array(
            'premium_fee'   => 35.00,
            'premium_slugs' => array(
                'aruba-blue', 'blue', 'patriot-blue', 'powder-blue', 'bright-purple', 
                'bright-orange', 'bright-cedar', 'cardinal-red', 'red', 'pink', 
                'lemon-yellow', 'tropical-lime-green', 'turf-green'
            ),
            'standard_slugs'=> array(
                'antique-mahogany', 'birchwood', 'black', 'brazilian-walnut', 'cedar', 
                'cherrywood', 'coastal-gray', 'dark-gray', 'driftwood-gray', 'ivory', 
                'light-gray', 'milwaukee-brown', 'natural-teak', 'seashell', 'tudor-brown', 
                'walnut', 'weathered-wood', 'white'
            )
        );
    }
}