<!DOCTYPE html>
<html lang="<?php language_attributes() ?>">
   <head>
    <meta charset="<?php echo bloginfo('charset'); ?>" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="">
      <meta name="keywords" content=" ">
      <meta name="author" content="elemis">
      <title><?php wp_title('|', true, 'right'); ?> <?php bloginfo('name'); ?></title>
      <?php //if ( is_front_page() ) : ?>
        <!-- <title><?php //bloginfo( 'title' ); ?></title> -->
        <?php //else : ?>
        <!-- <title><?php //wp_title( '|', true, 'right' ); ?></title> -->
    <?php //endif; ?> 
      <link rel="shortcut icon" href="<?php echo bloginfo('template_directory'); ?>/assets/img/favicon.jpg">
      <link rel="preload" href="<?php echo bloginfo('template_directory'); ?>/assets/css/fonts/thicccboi.css" as="style" onload="this.rel='stylesheet'">
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/fontawesome.min.css">

    <!-- CSS  ========================= -->
   <?php wp_head();?>
   </head>
   <body>
<!-- header area start here  -->
     <div class="content-wrapper">
    <header class="wrapper bg-light">
      <nav class="navbar navbar-expand-lg center-nav transparent navbar-light">
        <div class="container flex-lg-row flex-nowrap align-items-center">
          <div class="navbar-brand w-100">
            <a href="<?php echo home_url(); ?>">
              <img src="<?php echo get_field('header_logo','option'); ?>" srcset="<?php echo get_field('header_logo','option'); ?>" alt=""  style="width: 285px;"/>
            </a>
          </div>
          <div class="navbar-collapse offcanvas offcanvas-nav offcanvas-start">
            <div class="offcanvas-header d-lg-none">
              <h3 class="text-white fs-30 mb-0"></h3>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body ms-lg-auto d-flex flex-column h-100">
                <?php wp_nav_menu(
                    array('theme_location' => 'header-menu', 'container' => 'false', 'menu_class' => 'navbar-nav'));
                 ?>
                 <?php
                  //wp_nav_menu(array('theme_location' => 'menu-1', 'container' => 'ul', 'menu_class' => 'navbar-nav ml-auto', 'depth' => 2, 'fallback_cb' => false, 'add_li_class' => 'nav-item'));
                ?>
                 <?php
                                        $defaults = array(
                                            'theme_location'  => 'header-menu',
                                            'menu'            => 2,
                                            'container'       => false,
                                            'container_class' => '',
                                            'container_id'    => '',
                                            'menu_class'      => 'navbar-nav navbar-nav-custom',
                                            'menu_id'         => 'mainmenu',
                                            'echo'            => true,
                                            'fallback_cb'     => 'wp_page_menu',
                                            'before'          => '',
                                            'after'           => '',
                                            'link_before'     => '',
                                            'link_after'      => '',
                                            'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                                            'depth'           => 2,
                                            'walker'          => ''
                                            );
                                        wp_nav_menu( $defaults );
                                    ?>
              <!-- /.navbar-nav -->
              <div class="offcanvas-footer d-lg-none">
                <div>
                  <a href="cdn-cgi/l/email-protection.html#ff99968d8c8bd1939e8c8bbf9a929e9693d19c9092" class="link-inverse"><span class="__cf_email__" data-cfemail="1b72757d745b7e767a727735787476">[email&#160;protected]</span></a>
                  <br /> 00 (123) 456 78 90 <br />
                  <nav class="nav social social-white mt-4">
                    <a href="<?php echo get_field('twitter_link','option'); ?>"><i class="uil uil-twitter"></i></a>
                    <a href="<?php echo get_field('facebook_link','option'); ?>"><i class="uil uil-facebook-f"></i></a>
                    <a href="<?php echo get_field('instagram_link','option'); ?>"><i class="uil uil-instagram"></i></a>
                    <a href="<?php echo get_field('youtube_link','option'); ?>"><i class="uil uil-youtube"></i></a>
                  </nav>
                  <!-- /.social -->
                </div>
              </div>
              <!-- /.offcanvas-footer -->
            </div>
    
            <!-- /.offcanvas-body -->
          </div>
             <div class="navbar-other w-100 d-flex ms-auto">
            <ul class="navbar-nav flex-row align-items-center ms-auto">
            
              <li class="nav-item d-lg-none">
                <button class="hamburger offcanvas-nav-btn"><span></span></button>
              </li>
            </ul>
            <!-- /.navbar-nav -->
          </div>
        </div>
        <!-- /.container -->
      </nav>
      <!-- /.navbar -->
    </header>
<!-- /header -->


