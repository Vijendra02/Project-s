 <!-- Footer Start-->
     <footer class=" text-inverse">
    <div class="container ">
      <!--/div -->
      <hr>
      <div class="row gy-6 gy-lg-0">
        <!--<div class="col-md-2 col-lg-2">
          <div class="widget">
            <img class="mb-4" src="assets/img/logo-light.png" srcset="./assets/img/footer.png " alt="" />
          </div>
        </div>-->
         <div class="col-md-6 col-lg-6">
          <div class="widget">
            <!-- <nav class="nav social social-white"> -->
              <?php wp_nav_menu(array(
                    "theme_location" => "footer",
                    "menu" => "Footer Nav 1",
                    "menu_class" => "nav social social-white"
                )) ?>
            <p class="mb-4"><?php echo get_field('footer_copyright','option'); ?></p>
            <!-- /.social -->
          </div>
          <!-- /.widget -->
        </div>
        <!-- /column -->
        <!-- /column -->
      </div>
      <!--/.row -->
    </div>
    <!-- /.container -->
  </footer>
  <div class="progress-wrap">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
  </div>

    <!--  JS -->
    <script src="<?php echo bloginfo('template_directory'); ?>/assets/js/plugins.js"></script>

    <script src="<?php echo bloginfo('template_directory'); ?>/assets/js/theme.js"></script>

<?php wp_footer(); ?>

<!-- footer area end here -->





