<?php 
/*
** Template Name: Blog
*/
get_header(); ?>
<!-- CONTENT START -->
        <div class="page-content">
        
            <!-- Inner Banner -->
            <div class="mt-bnr-inr overlay-wraper" style="background-image:url('<?php echo bloginfo('template_url'); ?>/images/banner/about-banner.jpg');">
            	<div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                    <div class="mt-bnr-inr-entry">
                        <h1 class="text-white"><?php the_title(); ?></h1>
                        <!-- Breadcrumb -->                            
                        <ul class="mt-breadcrumb breadcrumb-style-1">
                            <li><a href="<?php echo home_url(); ?>">Home</a></li>
                            <li><?php the_title(); ?></li>
                        </ul>
                        
                    </div>
                </div>
            </div>
  <!--end section-->
      <div class="container">
       <div class="row">
          <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $args = array(
                    'post_type' => 'post',
                    'order' => 'ASC', // ascending order
                    'orderby' => 'date', // order by date
                    'posts_per_page' => 2, // Adjust as needed
                    'paged' => $paged
                );
            
                $custom_query = new WP_Query($args);
            
                if ($custom_query->have_posts()) :
                while ($custom_query->have_posts()) : $custom_query->the_post();
            ?>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="ce-feature-box-52 margin-bottom">
              <div class="ce-post-img"> <a href="<?php the_permalink(); ?>">
              <div class="info-badge"><span class="icon-pencil icon"></span>Blog</div>
                <div class="overlay"><i class="fa fa-plus" aria-hidden="true"></i> </div>
                </a> <img src="<?php echo the_post_thumbnail_url(); ?>" alt="" class="img-responsive"/> </div>
              <div class="text-box padd-1 shadow">
                <h5 class="less-mar-1 title"><a href="n"><?php the_title(); ?></a></h5>
				<div class="box-left"><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;
				<?php the_time('F, j, Y'); ?>
               </div>
               <p><?php 
                $excerpt = get_the_excerpt();
                $excerpt = substr( $excerpt , 0, 100); 
                echo $excerpt;
                ?></p>
                <!-- <p><?php //echo wp_trim_words( get_the_content(), 35, '...' ); ?></p> -->
				  <a class="btn btn-dark btn-round btn-medium uppercase" href="<?php the_permalink(); ?>"><i class="fa fa-play-circle" aria-hidden="true"></i> Read more</a>
              </div>
            </div>
          </div>
          <!--end item-->
          
          <?php endwhile;
            
                    // Add pagination links
                    echo '<div class="pagination-box-row">';
                    echo paginate_links(array(
                        'total' => $custom_query->max_num_pages,
                        'current' => max(1, get_query_var('paged')),
                        'prev_text' => __('« Previous'),
                        'next_text' => __('Next »'),
                    ));
                    echo '</div>';
            
                    // Reset post data
                    wp_reset_postdata();
                else :https://wordpressc.goigi.biz/askemils/blog/
                    // No posts found message
                    echo '<p>No posts found.</p>';
                endif;
                ?>
        </div>
   
      </div>

      <?php
/*
 * Template Name: Services
 * *  Template Post Type: services'
 *
 * Description: A custom template for displaying 'service' post types.
 * Note: This template will only be applied to posts of the 'service' post type.
 */

get_header(); ?>
<!-- Page Title -->
        <section class="page-title centred" style="background-image: url('<?php echo bloginfo('template_directory'); ?>/assets/images/background/page-title.jpg');">
            <div class="auto-container">
                <div class="content-box">
                    <div class="title">
                        <h1><?php the_title(); ?></h1>
                    </div>
                    <ul class="bread-crumb clearfix">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li><?php the_title(); ?></li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Page Title -->
        <section class="feature-section">
            <div class="auto-container">
                <div class="row clearfix">
                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="content_block_2">
                            <div class="content-box service">
                             <?php the_content(); ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; else : ?>
                    <!-- Fallback content if no posts are found -->
                    <p><?php _e( 'Sorry, no services found.' ); ?></p>
                <?php endif; ?>
                <!-- Loop End -->
            </div>
        </div>
    </section>
<?php get_footer(); ?>

      <section class="sidebar-page-container sec-pad-2">
    <div class="auto-container">
        <div class="row clearfix">
            <div class="col-lg-8 col-md-12 col-sm-12 content-column">
                <div class="blog-details-content">
                    <div class="news-block-two">
                        <div class="inner-box">
                            <figure class="image-box"><?php the_post_thumbnail(); ?></figure>
                            <div class="lower-content">
                                <ul class="post-info clearfix">
                                    <li><i class="far fa-user-circle"></i><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></li>
                                    <li><i class="far fa-calendar-alt"></i><?php echo get_the_date('d M Y'); ?></li>
                                    <li><i class="far fa-comments"></i><a href="<?php comments_link(); ?>"><?php comments_number('No Comments', '1 Comment', '% Comments'); ?></a></li>
                                </ul>
                                <h2><?php the_title(); ?></h2>
                                <div class="text">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="comments-form-area">
                        <div class="group-title">
                            <h2>Leave a Comment</h2>
                        </div>
                        <?php
                        // Display comment form
                        comment_form(array(
                            'title_reply' => '',
                            'class_submit' => 'theme-btn-one',
                            'label_submit' => 'send message<i class="far fa-long-arrow-right"></i>',
                        ));
                        ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                <div class="blog-sidebar">
                    <div class="sidebar-widget post-widget">
                        <div class="widget-title">
                            <h3>Recent News</h3>
                        </div>
                        <div class="post-inner">
                            <?php
                            // Query for recent posts
                            $recent_posts = wp_get_recent_posts(array(
                                'numberposts' => 3, // Adjust the number of posts displayed as needed
                                'post_status' => 'publish'
                            ));
                            foreach ($recent_posts as $post) : ?>
                                <div class="post">
                                    <figure class="post-thumb">
                                        <a href="<?php echo get_permalink($post['ID']); ?>">
                                            <?php echo get_the_post_thumbnail($post['ID'], 'thumbnail'); ?>
                                        </a>
                                    </figure>
                                    <p><i class="far fa-calendar-alt"></i><?php echo get_the_date('d M Y', $post['ID']); ?></p>
                                    <h5><a href="<?php echo get_permalink($post['ID']); ?>"><?php echo $post['post_title']; ?></a></h5>
                                    <div class="link"><a href="<?php echo get_permalink($post['ID']); ?>">Read more<i class="far fa-long-arrow-right"></i></a></div>
                                </div>
                            <?php endforeach; wp_reset_query(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

 </div>
<?php get_footer(); ?>