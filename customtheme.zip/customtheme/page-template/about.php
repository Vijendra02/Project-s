<?php 
/*
** Template Name: About Us
*/
get_header();?>
 <section class="wrapper bg-light">
      <div class="container pt-10 pt-md-14 pb-14 pb-md-0">
        <div class="row gx-md-8 gx-lg-12 gy-3 gy-lg-0 mb-13">
        <h2><?php the_field('management_heading'); ?></h2>
          <div class="col-lg-2">
    
            <img src="<?php the_field('president_image'); ?>" class=" mb-3" alt="">
           
      </div>
          <!-- /column -->
          <div class="col-lg-10">
        <h4><?php the_field('president_name'); ?></h4>
            <p class="  my-3"><?php the_field('about_president'); ?></p>
            
          </div>
          <!-- /column -->
        </div>
    
     <div class="row gx-md-8 gx-lg-12 gy-3 gy-lg-0 mb-13">
          <div class="col-lg-2">
    
            <img src="<?php the_field('asset_manager_image'); ?>" class=" mb-3" alt="">
           
      </div>
          <!-- /column -->
          <div class="col-lg-10">
        <h4><?php the_field('asset_manager_name'); ?></h4>
            <p class="  my-3"><?php the_field('about_asset_manager'); ?></p>
            
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
    <!-- /section -->
<?php get_footer();?>