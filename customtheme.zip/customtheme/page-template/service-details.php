<?php
/*
 * Template Name: Services
 * *  Template Post Type: services'
 *
 * Description: A custom template for displaying 'service' post types.
 * Note: This template will only be applied to posts of the 'service' post type.
 */

get_header(); ?>
<!-- Page Title -->
        <section class="page-title centred" style="background-image: url('<?php echo bloginfo('template_directory'); ?>/assets/images/background/page-title.jpg');">
            <div class="auto-container">
                <div class="content-box">
                    <div class="title">
                        <h1><?php the_title(); ?></h1>
                    </div>
                    <ul class="bread-crumb clearfix">
                        <li><a href="<?php echo home_url(); ?>">Home</a></li>
                        <li><?php the_title(); ?></li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Page Title -->
        <section class="feature-section">
            <div class="auto-container">
                <div class="row clearfix">
                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="content_block_2">
                            <div class="content-box service">
                             <?php the_content(); ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; else : ?>
                    <!-- Fallback content if no posts are found -->
                    <p><?php _e( 'Sorry, no services found.' ); ?></p>
                <?php endif; ?>
                <!-- Loop End -->
            </div>
        </div>
    </section>
<?php get_footer(); ?>
