<?php
/*
** Template Name: Home
*/ 
get_header();?>
<!-- hero-section area start here  -->
       <section class="wrapper bg-light">
      <div class="container pt-10 pt-md-14 pb-14 pb-md-0">
        <div class="row gx-md-8 gx-lg-12 gy-3 gy-lg-0 mb-13">
          <div class="col-lg-6">
            <?php the_field('live_webinar_videos'); ?>
             <p> <?php the_field('live_webinar_title'); ?></p>
          </div>
          <!-- /column -->
          <div class="col-lg-6">
            <p class="  my-3"><?php the_field('live_webinar_desc'); ?></p>
            
            <a href="<?php the_field('get_started_button_link'); ?>" class="btn more hover"><?php the_field('get_started_button'); ?></a>
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
        <div class="row gx-lg-8 gx-xl-12 gy-6 gy-md-0 text-center">
			<?php if(have_rows('deals_section')):
			  while(have_rows('deals_section')):the_row(); 
			  $service_name = get_sub_field('service_name');
			  $service_desc = get_sub_field('service_desc');
			  $service_image = get_sub_field('service_image');
			?>
            <div class="col-md-6 col-lg-4">
              <h4><?php echo $service_name; ?></h4>
              <p class="mb-2 text-indent"><?php echo $service_desc; ?></p>
               <img src="<?php echo $service_image; ?>" class=" mb-3" alt="">
           </div>
			<?php endwhile; endif; wp_reset_query(); ?>
          </div>
      </div>
      <!-- /.container -->
    </section>
    <!-- /section -->
    
    <section class="wrapper bg-light">
      <div class="container pt-10 pt-md-14 pb-14 pb-md-0">
        <div class="row gx-md-8 gx-lg-12 gy-3 gy-lg-0 mb-13">
         
          <!-- /column -->
          <div class="col-lg-7">
            <h4 class=" text-red my-3"><b><?php the_field('agents_heading'); ?></b></h4>
          </div>
          <!-- /column -->
           <div class="col-lg-5">
<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
  </div>
  
  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php the_field('carousel_image_1'); ?>" alt=" " class="d-block" style="width:100%">
    </div>
    <div class="carousel-item">
      <img src="<?php the_field('carousel_image_2'); ?>" alt="" class="d-block" style="width:100%">
    </div>
    <div class="carousel-item">
      <img src="<?php the_field('carousel_image_3'); ?>" alt=" " class="d-block" style="width:100%">
    </div>
    <div class="carousel-item">
      <img src="<?php the_field('carousel_image_4'); ?>" alt=" " class="d-block" style="width:100%">
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
          </div>
        </div>
        <!-- /.row -->
    <div class="row">
          <div class="col-xl-12 o">
            <div class="row gy-10 gx-lg-8 gx-xl-12">
              <div class="col-lg-5">
                <div class="col-md-10 text-center" style="padding: 20px;background: #5de72b;margin-bottom:20px">
                 <p class="text-black"> <b><?php the_field('price_calculator_title'); ?></b></p>
                    </div>
                <div class="contact-form needs-validation">
                <?php echo do_shortcode('[contact-form-7 id="107" title="Get In Touch"]'); ?>
                 </div>
                
                <!-- /form -->
              </div>
              <!--/column -->
              <div class="col-lg-7">
            <h4 class=" my-3"><b><?php the_field('deals_headline'); ?></b></h4>
                 <a href="<?php the_field('get_started_now_link'); ?>" class="btn more hover"><?php the_field('get_started_now'); ?></a>
              </div>
              <!--/column -->
            </div>
            <!--/.row -->
          </div>
          <!-- /column -->
        </div>
      </div>
      <!-- /.container -->
    </section>
    <!-- /section -->
  
    <!-- /section -->
  </div>
  <!-- /.content-wrapper -->
<?php get_footer();?>