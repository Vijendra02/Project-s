<?php
/**
* Template Name: Custom Template
*/
get_header() ; ?>
<div class="breadcrumb-section jarallax pixels-bg" data-jarallax data-speed="0.6">
         <div class="container custom-heads text-center">
		    <div class="custom-header" style="background-image:url('<?php the_field('custom_headers'); ?>') ">
				<?php the_title('<h1 class="entry-title">', '</h1>'); ?>
                 <h1><?php the_title();?></h1>
			</div>
         </div>
      </div>
 <div class="section-block">
 <div class="container">
<?php
if ( have_posts() ) :
while ( have_posts() ) : the_post();
the_content();
endwhile; endif; ?>
</div>
</div>
<?php get_footer() ; ?>