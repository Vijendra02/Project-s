<div class="find-veteran-wrapper">

  <!-- SECTION SEARCH INFO -->
  <div class="fv-field-group">
    <label for="sectionSelect" class="fv-field-label">
      Monument Section
    </label>

    <select id="sectionSelect" class="fv-search-input mb-3">
      <option value="">Select Section</option>
    </select>
  </div>

  <!-- LOCATION SEARCH INFO -->
  <div class="fv-field-group">
    <label for="locationSelect" class="fv-field-label">
      Brick Location
    </label>

    <select id="locationSelect" class="fv-search-input mb-3" disabled>
      <option value="">Select Location</option>
    </select>
  </div>

  <!-- VIEW BUTTON -->
  <button id="viewVeteran" class="fv-search-button" disabled>
    View Veteran Details
  </button>

  <!-- RESULT -->
  <div id="veteranResult"></div>

</div>