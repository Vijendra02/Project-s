<?php
/**
 * Template part for displaying post archives and search results
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>

<div class="col-lg-4 col-md-6 col-sm-12 col-12">
                    <!-- single blog area start -->
                    <div class="single-blog-area-one">
                        <a href="<?php the_permalink(); ?>" class="thumbnail">
                            <?php the_post_thumbnail('medium', array('class' => '')); ?>
                        </a>
                        <div class="inner">
                            <div class="blog-top">
                                <span>By <?php echo get_the_author(); ?></span>
                                <span><?php echo get_the_date('j F, Y'); ?></span>
                            </div>
                            <a class="title" href="<?php the_permalink(); ?>">
                                <h5 class="title"><?php the_title(); ?></h5>
                            </a>
                            <a href="<?php the_permalink(); ?>" class="rts-btn btn-seconday">Read details <i
                                    class="fa-regular fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <!-- single blog area end -->
                </div>
