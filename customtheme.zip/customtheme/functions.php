<?php
 //css include by functions
// function my_themestyle(){
  
//  wp_register_style('style.css',get_template_directory_uri().'/assets/css/style.css','all');
//  wp_enqueue_style('style.css');
//  wp_register_style('plugins.css',get_template_directory_uri().'/assets/css/plugins.css','all');
//  wp_enqueue_style('plugins.css');
//  wp_register_style('violet.css',get_template_directory_uri().'/assets/css/colors/violet.css','all');
//  wp_enqueue_style('violet.css');
//  wp_register_style('custom-style.css',get_template_directory_uri().'/custom-style.css','all');
//  wp_enqueue_style('custom-style.css');
// }
// add_action('wp_enqueue_scripts','my_themestyle');

// Register Custom Navigation Walker
require_once('wp_bootstrap_navwalker.php');
function register_my_menus() {
  register_nav_menus(
    array(
      'header-menu' => __( 'Header Menu' ),
      'mobile-menu' => __( 'Mobile Menu' ), 
      'footer-menu' => __( 'Footer Menu' ), 
    )
  );
}
add_action( 'init', 'register_my_menus' );  
add_theme_support( 'post-thumbnails' );

/*------start-Custom-logo------*/
function themename_custom_logo_setup() {
    $defaults = array(
        'height'               => 100,
        'width'                => 400,
        'flex-height'          => true,
        'flex-width'           => true,
        'header-text'          => array( 'site-title', 'site-description' ),
        'link-homepage-logo' => true, 
    );
 
    add_theme_support( 'custom-logo', $defaults );
}
 
add_action( 'after_setup_theme', 'themename_custom_logo_setup' );
/**------end-Custom-logo------*/
/**
* Registers a new post type
* @uses $wp_post_types Inserts new post type object into the list
*
* @param string  Post type key, must not exceed 20 characters
* @param array|string  See optional args description above.
* @return object|WP_Error the registered post type object, or an error object
*/
if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Header Settings',
		'menu_title'	=> 'Header',
		'parent_slug'	=> 'theme-general-settings',
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Footer Settings',
		'menu_title'	=> 'Footer',
		'parent_slug'	=> 'theme-general-settings',
	));
}
add_action( 'init', 'testimonial' );
function testimonial() {
	$labels = array(
		'name'               => _x( 'Testimonial', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Testimonial', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Testimonial', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Testimonial', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'Testimonial', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Testimonial', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Testimonial', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Testimonial', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Testimonial', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Testimonial', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Testimonial', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Testimonial', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No Testimonial found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No Testimonial found in Trash.', 'your-plugin-textdomain' )
	);
	$args = array(
		'labels'             => $labels,
        'description'        => __( 'Description.', 'your-plugin-textdomain' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'testimonial' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
	);
register_post_type( 'testimonial', $args );
 }

 function xz_custom_post_type_init() {
    $xz_cust_post_argu = '';
    $xz_cust_post_argu = array(
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_nav_menus'  => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => true,
            'menu_position'      => null,
            'menu_icon'          => null,
            'supports'           => array( 'title', 'editor' )
        );

 register_post_type(
    'services', array(
      'labels' => array('name' => __( 'Services' ), 'singular_name' => __( 'services' ) ),
      'hierarchical' => true,
        'public' => true,
        'rewrite' => array(
            'slug'       => 'services',
            'with_front' => false,
        ),
      'menu_icon' => 'dashicons-admin-site',
      'has_archive' => true,
      'parent' => 'Services',
      'supports' => array('page-attributes','title', 'editor', 'thumbnail', 'comments', 'excerpt'),
      $xz_cust_post_argu,
    )
  );  
  
}
add_action( 'init', 'xz_custom_post_type_init' );


function ac_custom_post_type_init() {
    $ac_cust_post_argu = '';
    $ac_cust_post_argu = array(
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_nav_menus'  => true,
            'query_var'          => true,
            'has_archive'        => true,
            'hierarchical'       => true,
            'menu_position'      => null,
            'menu_icon'          => null,
            'supports'           => array( 'title', 'editor' )
        );

     
  register_post_type(
    'project', array(
      'labels' => array('name' => __( 'Our Projects' ), 'singular_name' => __( 'project' ) ),
      'hierarchical' => true,
        'public' => true,
        'rewrite' => array(
            'slug'       => 'project',
            'with_front' => false,
        ),
      'menu_icon' => 'dashicons-admin-site',
      'has_archive' => true,
      'parent' => 'Projects',
      'supports' => array('page-attributes','title', 'editor', 'thumbnail', 'comments', 'excerpt'),
      $ac_cust_post_argu,
    )
  );  
  
}
add_action( 'init', 'ac_custom_post_type_init' );


 /*********************li class add**********************/
add_filter ( 'nav_menu_css_class', 'so_37823371_menu_item_class', 10, 4 );
function so_37823371_menu_item_class ( $classes, $item, $args, $depth ){
  $classes[] = 'page_item current_page_item active';
  return $classes;
}
/****************li a class add******************/
function add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_link_atts');
/****************Active class********************/
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
function special_nav_class ($classes, $item) {
    if (in_array('current-menu-item', $classes) ){
        $classes[] = 'nav-item active';
    }
    return $classes;
}
function change_submenu_class($menu) {  
  $menu = preg_replace('/ class="sub-menu"/','/ class="sub-menu" /',$menu);  
  return $menu;  
}  
add_filter('wp_nav_menu','change_submenu_class');

/*------start-Custom-footer------*/

if ( function_exists('register_sidebar') ) register_sidebar(array( 'name' => 'Footer Widget Area 1', 'id' => 'footer-widget-area-1', 'description' => 'First footer widget area appear in the footer', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h3 class="widgettitle">', 'after_title' => '</h3>', ));
if ( function_exists('register_sidebar') ) register_sidebar(array( 'name' => 'Footer Widget Area 2', 'id' => 'footer-widget-area-2', 'description' => 'Second footer widget area appear in the footer', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h3 class="widgettitle">', 'after_title' => '</h3>', ));

 if ( function_exists('register_sidebar') ) register_sidebar(array( 'name' => 'Footer Widget Area 3', 'id' => 'footer-widget-area-3', 'description' => 'Third footer widget area appear in the footer', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h3 class="widgettitle">', 'after_title' => '</h3>', )); 

 if ( function_exists('register_sidebar') ) register_sidebar(array( 'name' => 'Footer Widget Area 4', 'id' => 'footer-widget-area-4', 'description' => 'Fourth footer widget area appear in the footer', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h3 class="widgettitle">', 'after_title' => '</h3>', ));

/*------end-Custom-footer------*/
class SocialWidget extends WP_Widget
{
  function SocialWidget()
  {
    $widget_ops = array('classname' => 'SocialWidget', 'description' => 'Display Social Icons' );
    $this->WP_Widget('SocialWidget', 'Social Icons', $widget_ops);
  }

  function form($instance)
  {
    $instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
    $title = $instance['title'];
?>
  <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo attribute_escape($title); ?>" /></label></p>
<?php
  }

  function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['title'] = $new_instance['title'];
    return $instance;
  }

  function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);

    echo $before_widget;
    $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);

    if (!empty($title))
      echo $before_title . $title . $after_title;;

    // WIDGET CODE GOES HERE
    echo "<h1>This is my new widget!</h1>";

    echo $after_widget;
  }

}
  /*** Countdown Timer Shortcode ***/
function next_event_shortcodes_init() {
  add_shortcode('next_event', 'next_event_shortcode');
}
add_action('init', 'next_event_shortcodes_init');

function next_event_shortcode ($atts = [])
{
  // normalize attribute keys to lowercase
  $atts = array_change_key_case((array)$atts, CASE_LOWER);
  if (!array_key_exists("date", $atts)) return false;

  $time_remaining = strtotime($atts['date']) - time();

  if ($time_remaining < 0) {
    $time_remaining = 0;
  }

  $total_days_remaining = ceil($time_remaining / (60 * 60 * 24));

  if ($total_days_remaining >= 7) {
    $weeks_remaining = sprintf("%02d", floor($total_days_remaining / 7));
    $days_remaining = sprintf("%02d", $total_days_remaining % 7);
  } else {
    $weeks_remaining = sprintf("%02d", 0);
    $days_remaining = sprintf("%02d", $total_days_remaining);
  }
  
  echo "
  <div class='next-event'>
    $weeks_remaining Weeks, $days_remaining Days
  </div>";
}

  add_filter("the_content", "plugin_myContentFilter");

  function plugin_myContentFilter($content)
  {
    // Take the existing content and return a subset of it
    return substr($content, 0, 20000);
  }
  function mytheme_custom_excerpt_length( $length ) {
    return 200;
}
add_filter( 'excerpt_length', 'mytheme_custom_excerpt_length', 999 );


add_filter( 'acf/admin/prevent_escaped_html_notice', '__return_true' );
add_filter( 'wpcf7_validate_configuration', '__return_false' );


// function load_js() {
//  wp_register_script('bootstrap.min.js',get_template_directory_uri().'/assets/js/bootstrap.min.js','all');
//  wp_enqueue_script('bootstrap.min.js');
// }
// add_action('wp_enqueue_scripts','load_js');

function mytheme_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );