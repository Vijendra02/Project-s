<?php 
/*
** Template Name: Join
*/
get_header();?>
<section class="wrapper ">
      <div class="container pt-10 pb-20 pt-md-14 pb-md-22 text-center">
        <div class="row">
       <h2><?php the_field('join_heading'); ?></h2>
          <!-- /column -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
   <section class="wrapper">
      <div class="container  ">
        <div class="pricing-wrapper  mt-n18 mt-md-n21 mb-12 mb-md-15">
     
          <div class="row gy-6 mt-3 mt-md-5">
            <?php if(have_rows('pricing_section')):
            while(have_rows('pricing_section')):the_row();
            $plan_name = get_sub_field('plan_name');
            $plan_offers = get_sub_field('plan_offers');
            $plan_button = get_sub_field('plan_button');
            $plan_button_link = get_sub_field('plan_button_link');
            ?>
            <div class="col-md-6 col-lg-4">
              <div class="pricing card text-center">
                <div class="card-body">
                  
                  <h4 class="card-title"><?php echo $plan_name; ?></h4>
                  <!--/.prices -->
                  <ul class="icon-list  bullet-soft-primary mt-8 mb-9 text-start">
                    <?php echo $plan_offers; ?>
                  </ul>
                  <a href="<?php echo $plan_button_link; ?>" class="btn btn-primary rounded-pill" style="background:rgb(205, 127, 50) !important"><?php echo $plan_button; ?></a>
                </div>
                <!--/.card-body -->
              </div>
              <!--/.pricing -->
            </div>
            <!--/column -->
            
           <?php endwhile; endif; wp_reset_query(); ?>
          </div>
          <!--/.row -->
        
        </div>
      </div>
      <!-- /.container -->
    </section>
        <!-- /.row -->
      <section class="wrapper bg-light">
    
      <div class="container  pt-md-14 pb-14 pb-md-0 text-center">
   <div class="row gx-md-8 gx-lg-12 gy-3 gy-lg-0 mb-13">
          <!-- /column -->
          <div class="col-lg-10 offset-lg-1">
            <p class="  my-3"><?php the_field('membership_desc'); ?>
            </p>
          </div>
          <!-- /column -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>

    <!-- /section -->
<?php get_footer();?>