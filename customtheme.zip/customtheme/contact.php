<?php 
/*
** Template Name: Contact Us
*/
get_header();?>
<section class="wrapper bg-light">
      <div class="container pt-10 pt-md-14 pb-14 pb-md-0">
        <div class="row gx-md-8 gx-lg-8 gy-3 gy-lg-0 mb-13">
        <h2><?php the_field('contact_heading'); ?></h2>
          <div class="col-lg-6">
          <p><?php the_field('contact_email_address'); ?></p>
          <p><?php the_field('contact_address'); ?></p></br>
           <?php the_field('contact_map_area'); ?>
           
          </div>
          <!-- /column -->
          <div class="col-lg-6">
            <div class="contact-form needs-validation">
              <?php echo do_shortcode('[contact-form-7 id="106" title="Contact Form"]'); ?>
            </div>
          </div>
          <!-- /column -->
        </div>
        
        <!-- /.row -->
      </div>
      <!-- /.container -->
    </section>
    <!-- /section -->
<?php get_footer();?>