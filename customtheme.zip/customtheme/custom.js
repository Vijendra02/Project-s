jQuery(document).ready(function ($) {

    /* ===============================
       LOAD SECTIONS ON PAGE LOAD
    =============================== */
    $.post(fvAjax.ajaxurl, {
        action: 'get_sections'
    }, function (response) {

        let sections = JSON.parse(response);
        let $section = $('#sectionSelect');

        $section.html('<option value="">Select Section</option>');

        sections.forEach(function (section) {
            $section.append(`<option value="${section}">${section}</option>`);
        });
    });


    /* ===============================
       ON SECTION CHANGE → LOAD LOCATIONS
    =============================== */
    $('#sectionSelect').on('change', function () {

        let section = $(this).val();
        let $location = $('#locationSelect');

        if (!section) {
            $location.prop('disabled', true);
            return;
        }

        $location.prop('disabled', true);
        $location.html('<option>Loading...</option>');

        $.post(fvAjax.ajaxurl, {
            action: 'get_locations',
            section: section
        }, function (response) {

            let locations = JSON.parse(response);

            $location.html('<option value="">Select Location</option>');

            locations.forEach(function (item) {
                $location.append(
                    `<option value="${item.post_id}">${item.label}</option>`
                );
            });

            $location.prop('disabled', false);
        });
    });


    /* ===============================
       ENABLE VIEW BUTTON
    =============================== */
    $('#locationSelect').on('change', function () {

        $('#viewVeteran').prop('disabled', !$(this).val());
    });


    /* ===============================
       VIEW VETERAN DETAILS
    =============================== */
    $('#viewVeteran').on('click', function () {

        let post_id = $('#locationSelect').val();

        if (!post_id) return;

        $('#veteranResult').html('<p>Loading...</p>');

        $.post(fvAjax.ajaxurl, {
            action: 'get_veteran_details',
            post_id: post_id
        }, function (response) {

            let data = JSON.parse(response);

            let html = `
                <div class="fv-result-card">
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Years Served:</strong> ${data.years}</p>
                    <p><strong>Brick Location:</strong> ${data.bricklocation}</p>
            `;

            if (data.locations.length) {
            html += '<p><strong>Location Section \\ Row \\ Column:</strong></p>';
            html += '<ul>';
        
            data.locations.forEach(loc => {
                html += `<li>${loc.section} \\ ${loc.row} \\ ${loc.column}</li>`;
            });
        
            html += '</ul>';
        }


            html += '</div>';

            $('#veteranResult').html(html);
        });
    });

});
