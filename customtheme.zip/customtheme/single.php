<?php
/**
 * The template for displaying all single posts Blog
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post();
	?>
<section class="blog-details">
            <div class="container">
                <div class="row">
                    <!--Start Blog Details Content-->
                    <div class="col-xl-8">
                        <div class="blog-details__content">

                            <div class="blog-list-page__single">
                                <div class="blog-list-page__single-img">
                                     <?php the_post_thumbnail(); ?>
                                   
                                </div>
                                <div class="blog-list-page__single-content">

                                    <div class="blog-list-page__single-content-top">
                                        <ul class="meta-box">
                                            <li>
                                                <div class="icon">
                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                </div>
                                                <div class="text">
                                                    <p><a href="<?php the_permalink(); ?>"><?php echo get_the_date('M d, Y'); ?></a></p>
                                                </div>
                                            </li>

                                           

                                            <li>
                                                <div class="icon">
                                                    <i class="fa fa-user" aria-hidden="true"></i>
                                                </div>
                                                <div class="text">
                                                    <p><a href="<?php the_permalink(); ?>">By <?php echo get_the_author(); ?></a></p>
                                                </div>
                                            </li>
                                        </ul>

                                        
                                    </div>

                                    <h2><?php the_title(); ?></h2>

                                </div>
                            </div>

                          

                            <div class="blog-details__content-text2">
                                <?php echo the_content(); ?>
                            </div>

                          
                          
                        </div>
                    </div>
                    <!--End Blog Details Content-->

                    <!--Start Sidebar-->
                    <div class="col-xl-4">
                        <div class="sidebar">
                          
                            
                            <div class="sidebar__single sidebar__post wow animated fadeInUp" data-wow-delay="0.3s">
                                <div class="title-box">
                                    <h2>Latest Blog</h2>
                                </div>

                                <ul class="sidebar__post-list list-unstyled">
                                       <?php
                                            $args = array(
                                                 'numberposts' => -1,
                                                'offset' => 0,
                                                'category' => 0,
                                                'orderby' => 'post_date',
                                                'order' => 'ASC',
                                                'include' => '',
                                                'exclude' => '',
                                                'meta_key' => '',
                                                'meta_value' =>'',
                                                'post_type' => 'post',
                                                'post_status' => 'publish',
                                                'suppress_filters' => true
                                            );
                                            $recent_posts = wp_get_recent_posts( $args );
                                            foreach ($recent_posts as $recentpost )  {
                                        ?> 
                                    <li>
                                        <div class="sidebar__post-image">
                                            <?php $blog_image = wp_get_attachment_url( get_post_thumbnail_id($recentpost["ID"], array(80,80)) ); ?>
                                                <img src="<?php echo $blog_image; ?>" alt="<?php echo $recentpost["post_title"]; ?>">
                                        </div>
                                        <div class="sidebar__post-content">
                                            <h3>
                                                <a href="<?php echo get_permalink($recentpost["ID"]); ?>"><?php echo $recentpost["post_title"]; ?>
                                                </a>
                                            </h3>
                                            <span class="sidebar__post-content-meta"><i class="fa fa-calendar" aria-hidden="true"></i>
                                                <?php echo get_the_date('M d, Y', $recentpost["ID"]) ?></span>
                                        </div>
                                    </li>
                                        <?php } wp_reset_query(); ?>
                                </ul>
                            </div>
                           
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>	
	

<?php
endwhile; 

get_footer();
